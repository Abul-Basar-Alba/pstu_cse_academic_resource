x ="Hello world"
print(len(x))#it also count the space..