for x in "Banana":
    print(x);