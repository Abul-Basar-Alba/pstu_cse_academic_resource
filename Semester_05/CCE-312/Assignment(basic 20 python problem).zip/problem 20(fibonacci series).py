x = int(input())
a = 0
b = 1
next = b
count = 1

while count <= x:
    print(next ,end=" ")
    count = count + 1
    a = b
    b = next
    next = a+b

print()
