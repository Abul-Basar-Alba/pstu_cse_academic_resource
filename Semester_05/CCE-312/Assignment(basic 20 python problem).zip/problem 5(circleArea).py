from math import pi

redius = float(input("Enter the redius of the circle: " ))
 
area = (pi*redius*redius)

print("The area of the circle is : "+str(area));