thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
thislist.reverse()
print(thislist) #Reverse List Alphanumerically

list = [100, 50, 65, 82, 23]
list.reverse()
print(list) #reverse list numerically.