list = ["apple","banana","cherry"]
i = 0
while i < len(list):
    print(list[i])
    i = i+1