import random
print(random.randrange(1,100)) #print a random numbrt between the range.