text = "The best things in our life are free"
if "free" in text:
    print("Yes, 'free' is present in the text")