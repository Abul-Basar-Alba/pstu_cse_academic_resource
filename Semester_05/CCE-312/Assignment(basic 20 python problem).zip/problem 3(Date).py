import platform
import datetime
print("The version is :")
print(platform.python_version())

now =  datetime.datetime.now()

print("Current date and time : ")
print(now.strftime("%Y-%m-%d %H:%M:%S"))