thislist = ["orange", "mango", "kiwi", "pineapple", "banana"]
thislist.sort()
print(thislist) #Sort List Alphanumerically

list = [100, 50, 65, 82, 23]
list.sort()
print(list) #Sort list numerically.