text = "Hello world"
print(text.upper())
print(text.lower())