#assignment opearator

d=5
sum=d+5
print(sum)

a=10
sum +=10
print(sum)


#now substraction
a=10
sum -=10
print(sum) 

#comparison operator

x=5
y=3
print(x==y)

print(x!=y)



