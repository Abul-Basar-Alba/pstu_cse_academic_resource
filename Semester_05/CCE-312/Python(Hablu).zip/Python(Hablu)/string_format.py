#string format 

num1=20
num2=50
print("This is my super number " , num1+num2)

#another example

num1=50
num2=50
print(f"Thisi is my super number {num1+num2}") #using f before the string and using mathmatical operation in the second bracket of the string
  
#can also use string data type  

x="Sakib" 

print(f"my name is {x}") 