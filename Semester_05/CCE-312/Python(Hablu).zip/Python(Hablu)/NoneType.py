#none data type 

x=None
print(type(x)) #to define a null value in python