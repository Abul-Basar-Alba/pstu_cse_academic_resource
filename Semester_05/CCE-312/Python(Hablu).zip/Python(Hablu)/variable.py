# step 1

name="Hey progarammer"
print(name);

#step 2

name=123456;
print(name);

#step 3

name=123456;
print("name");

#step 4

name=123456;
hablu="hey hablu prorammer"
print(name);

#step 5

name=123456;
print("name");
