class x:
    name = ""
    number = ""

a = x()  # Create an instance of class x
a.name = "eshan"  # Assign values to instance variables
a.number = 123
print(a.name, a.number)  # Output: eshan 123


#initialize the attributes using the __init__ method:

class x:
    def __init__(self, name, number):
        self.name = name
        self.number = number

a = x("eshan", 123)
print(a.name, a.number)  # Output: eshan 123
