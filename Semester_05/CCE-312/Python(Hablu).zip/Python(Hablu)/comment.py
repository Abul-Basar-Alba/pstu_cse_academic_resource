#for single line comment using # sy

print('Hello programmer');

''' for multiline comment using triple quotes'''

print('work hard and you will success one day');