#continue statement in python

for x in range(9):
    
    if x==3 :
        continue
    print(x)
    
    #another way of continue statement
    
Hablu=[1,2,3,4,5,6,7,8]

for x in range(len(Hablu)):
    if x==4:
        continue
    print(x)