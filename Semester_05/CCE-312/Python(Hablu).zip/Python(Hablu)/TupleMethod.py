x = (1, 3, 4, 5, 6, 7, 8, 9)

# Count the occurrences of 6 in the tuple
z = x.count(6)
print(z)

# Find the index of the element 4 in the tuple
y = x.index(4)
print(y)
