username = input("What is your name: ")
fatherName = input("What is your father's name: ")
motherName = input("What is your mother's name: ")
study = input("Which class do you read in: ")
relationship = input("What is your relationship status: ")

print(f"My dog's name is {username}, my dog's father's name is {fatherName}, "
      f"my dog's mother's name is {motherName}, my dog studies in class {study}, "
      f"and our relationship is {relationship}.")