#array in python
#array is a single variable where multiple variable is stored 
x=["a","b","c"]
print(x)

x[1]="k"
print(x)