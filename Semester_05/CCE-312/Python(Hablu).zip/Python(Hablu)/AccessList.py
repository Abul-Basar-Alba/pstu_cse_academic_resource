#access list of tuples
#direct access data from the list

d=["x","y","z","w"]
print(d[1])

#another way 

d=["x","y","z","w"]
print(type(d))
print(d[3])

#change list item

d[0]="a"
print("Now the list is : " ,d)