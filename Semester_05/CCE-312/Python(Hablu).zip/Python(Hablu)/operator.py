#python operator

a=20
b=10

#Addition operator

print(f"the total number is = ",a+b )

#susbtraction operator 

print(f"the substraction number is  =" ,a-b)


#multiplication operator

print(f" the multiplication is = ", a*b)


#division 

print(f" the division is = ", a/b)

#remainder

print(f" the remainder is = ", a%b)