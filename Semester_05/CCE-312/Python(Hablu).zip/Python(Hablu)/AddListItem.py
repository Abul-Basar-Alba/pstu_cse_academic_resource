#when append is used it means the new element is added in the last of the list

d=["a","b","c","d"]
d.append(10)
print(d)

#insert is used to insert element in specified position
#insert(index,string)

d=["a","b","c","d"]
d.insert(1,"k")
print(d)

