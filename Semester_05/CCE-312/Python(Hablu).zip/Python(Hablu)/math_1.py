a = min(30, 10, 20, 40, 100) #min() is used  to define the minimum number
print(a)


b = max(30, 10, 20, 40, 100) #max() is used to define the maximum number
print(b)


c=abs(-110) #abs is used to define the absolute value
print(c)


d=pow(5,3) #pow() is used to define the power of a number 
print(d)