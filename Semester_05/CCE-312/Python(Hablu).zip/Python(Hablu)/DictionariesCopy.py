x = {
    "name": "John",
    "age": 30,
    "city": "New York"
}

y = {
    "name": "sakib",
    "age": 22,
    "city": "Bangladesh"
    
}

y=x.copy()
print(y)

z= dict(x)
print(z)
