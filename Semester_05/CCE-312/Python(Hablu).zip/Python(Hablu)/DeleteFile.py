#delete file in python

import os
os.remove("hablu.html") #the html file is deleted


os.remove("dates.py") #the python file is deleted

#rmdir is used to delete a directory
 
import os 
os.rmdir("hablu")  #this is used to delete the folder