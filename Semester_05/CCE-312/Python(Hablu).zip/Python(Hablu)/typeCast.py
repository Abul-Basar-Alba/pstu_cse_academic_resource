#type cast= convert
#int() = for int value
#float() = for float value


name="12345"  #using type cast it should be declare number in " " mark because it can't convert string into number
print(name)

print(type(name))

#another way 

num="50"
print(float(num))

#another way 

x="5.5"
print(int(x))  #output error