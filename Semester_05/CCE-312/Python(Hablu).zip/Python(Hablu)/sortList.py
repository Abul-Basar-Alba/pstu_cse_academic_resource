#sort list in python
#x.sort() to sort list in ascending order

x=[10,1,2,5,7,8,4]
x.sort()
print(x)

y=["b","c","f","a","k"]
y.sort()
print(y)

#reverse list

num=[1,2,3,4,5,6,7]
num.reverse()
print(num)