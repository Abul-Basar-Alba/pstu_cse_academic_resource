x=(1,2,3)
y=("a","b","c")

z=x+y
print(z)
print(z*3)

#another  way

a = [10, 9, 8, 7]
b = [4, 5, 6, 7]

a.extend(b)  # Extend the list `a` with elements of `b`

print(a)

