#add set item in python

x={"a","b","c"}
x.add("d")
print(x) 

#update set

y={1,2,3,4,5,6}
z={4,5,6}

y.update(x)
print(y)