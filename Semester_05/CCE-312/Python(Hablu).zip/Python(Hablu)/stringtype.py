#string data type 

yourname="Sakib"
print(yourname)

myname="Hasan"
print(myname)

print(yourname+ myname)  #add two string together 

print('My name is ' + ' ' +myname) #add string with space in between 