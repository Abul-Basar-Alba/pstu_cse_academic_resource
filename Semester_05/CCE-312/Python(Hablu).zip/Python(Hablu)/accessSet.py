#access set item in python

x={"abul","babul","damn"}

for i in x:
    print(i)

#another way 

x={1,2,3,4,5,6}
for i in x:
    print(i)
#another way 

print(3 in x)
    
    