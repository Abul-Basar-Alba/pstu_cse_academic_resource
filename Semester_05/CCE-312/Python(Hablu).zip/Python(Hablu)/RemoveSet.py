#remove set item in python

x={"a","b","c"}
x.remove("b")
print(x)
x.pop()  # this will remove the last item in the list
print(x)


#another way in python

y={1,2,3,4,5,6}
y.remove(2)
print(y)

y.clear()
print(y) #this will remove all items in the list 
