#added two set in one line

x = {1,2,3,4}
y={7,8,9,10}

z=x.union(y) #union is used to add two set in one line
print(z)


#another way in the list

y.update(x) #update is also added tw add the list

print(y)