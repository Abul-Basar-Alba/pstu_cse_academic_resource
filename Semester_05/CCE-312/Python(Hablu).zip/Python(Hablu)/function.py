# Define the function
def x(a, b):
    sum = a + b
    print(sum)

# Call the function multiple times
x(20, 50)
x(30, 50)
x(40, 50)
x(50, 50)
x(60, 50)
x(70, 50)
x(80, 50)
x(90, 50)
x(100, 50)


def minus(x,y):
    z= x-y
    print(z)

# Call the function multiple times
minus(20, 50)
minus(30, 50)
minus(40, 50)
minus(50, 50)
minus(60, 50)
minus(70, 50)
minus(80, 50)
minus(90, 50)
minus(100, 50)

