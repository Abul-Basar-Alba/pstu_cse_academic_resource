from tkinter import Tk, Entry, Button, StringVar

class Calculator:
    def __init__(self, master):
        master.title("Calculator")
        master.geometry('357x420+0+0')  # Set window size and position
        master.config(bg='gray')  # Set background color
        master.resizable(False, False)  # Make the window non-resizable

        self.equation = StringVar()  # Holds the current equation
        self.entry_value = ''  # Tracks the input values
        
        # Entry widget to display the equation/result
        Entry(master, width=17, bg='#fff', font=('Arial Bold', 28), 
              textvariable=self.equation, justify='right').place(x=0, y=0)
        
        # Creating buttons for the calculator
        buttons = [
            ('7', 1, 0), ('8', 1, 1), ('9', 1, 2), ('/', 1, 3),
            ('4', 2, 0), ('5', 2, 1), ('6', 2, 2), ('*', 2, 3),
            ('1', 3, 0), ('2', 3, 1), ('3', 3, 2), ('-', 3, 3),
            ('0', 4, 0), ('.', 4, 1), ('+', 4, 2), ('=', 4, 3),
            ('C', 5, 0)
        ]
        
        for (text, row, col) in buttons:
            Button(master, text=text, width=9, height=2, bg='#fff', 
                   font=('Arial', 14), command=lambda t=text: self.on_button_click(t)).grid(row=row, column=col)
        
    def on_button_click(self, button_value):
        if button_value == "C":
            self.clear()
        elif button_value == "=":
            self.solve()
        else:
            self.entry_value += str(button_value)
            self.equation.set(self.entry_value)
    
    def clear(self):
        self.entry_value = ''
        self.equation.set(self.entry_value)
    
    def solve(self):
        try:
            result = eval(self.entry_value)
            self.equation.set(result)
            self.entry_value = str(result)  # Store result for further operations
        except Exception as e:
            self.equation.set("Error")
            self.entry_value = ""

# Run the calculator application
if __name__ == "__main__":
    root = Tk()
    calculator = Calculator(root)
    root.mainloop()
