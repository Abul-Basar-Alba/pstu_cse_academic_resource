import time  # Import the time module for adding delay

# Text to print line by line with corresponding delays (in seconds)
lines_with_delays = [
    ("So I'ma love you every night like it's the last night", 2),
    ("Like it's the last night", 3),
    ("If the world was ending, I'd wanna be next to you", 9),
    ("If the party was over and our time on Earth was through", 8),
    ("I'd wanna hold you just for a while and die with a smile", 10),
    ("If the world was ending, I'd wanna be next to you", 2)
]

# Print each line with its specific delay
for line, delay in lines_with_delays:
    print(line)
    time.sleep(delay)  # Wait for the specified time before printing the next line
