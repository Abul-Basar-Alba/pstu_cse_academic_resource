import pygame
import sys

# Initialize pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Interactive Dragon Cursor")

# Load dragon images
dragon_idle = pygame.image.load("dragon_idle.png")  # Replace with your image
dragon_move = pygame.image.load("dragon_move.png")  # Replace with your image

# Scale images if needed
dragon_idle = pygame.transform.scale(dragon_idle, (64, 64))  # Adjust size
dragon_move = pygame.transform.scale(dragon_move, (64, 64))

# Clock for controlling frame rate
clock = pygame.time.Clock()

# Main game loop
running = True
while running:
    # Fill the screen with a background color
    screen.fill((0, 0, 0))  # Black background

    # Get mouse position
    mouse_x, mouse_y = pygame.mouse.get_pos()

    # Get mouse movement
    mouse_rel = pygame.mouse.get_rel()

    # Choose the dragon image based on movement
    if mouse_rel == (0, 0):  # If the mouse is stationary
        dragon_image = dragon_idle
    else:
        dragon_image = dragon_move

    # Draw the dragon at the mouse position
    screen.blit(dragon_image, (mouse_x - 32, mouse_y - 32))

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update the screen
    pygame.display.flip()

    # Limit the frame rate
    clock.tick(60)

# Quit pygame
pygame.quit()
sys.exit()
